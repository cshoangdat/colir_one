#ifndef BASIC_H
#define BASIC_H

#include "config.h"
#include "stdio.h"
#include "stdbool.h"

#ifdef __cplusplus
extern "C" {
#endif

float getVerticalVelocity();
void setVerticalVelocity(float velocity);
float getAltitude();
void setAltitude(float alt);
bool encryptData(const uint8_t* input, uint8_t* output, size_t dataSize);
bool isCrytoInfoAvailable(void);

#ifdef __cplusplus
}
#endif

#endif
