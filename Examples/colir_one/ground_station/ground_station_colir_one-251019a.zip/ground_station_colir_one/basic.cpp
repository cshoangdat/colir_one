#include "basic.h"
#include "common.h"
#include "NVSDriver.h"
#include "string"
#include "stdlib.h"
#include "stdio.h"
#include <cstring>
#include <Crypto.h>
#include <ChaCha.h>
#include <RNG.h>
#include <string.h>

static float verticalVelocity = 0;
static float altitude = 0;


float getVerticalVelocity(){
  return verticalVelocity;
}

void setVerticalVelocity(float velocity){
  verticalVelocity = velocity;
}

float getAltitude(){
  return altitude;
}

void setAltitude(float alt){
  altitude = alt;
}

static void load_crypto_info(uint8_t* key, uint8_t* nonce){
    uint8_t* key_temp = (uint8_t*)malloc(32);
    if (NVSDriverReadBlob(NVS_NAMESPACE_SEC, NVS_KEY_SEC_KEY, &key_temp) == ESP_OK) {
        memcpy(key, key_temp, 32);
    }
    free(key_temp);

    uint8_t* nonce_temp = (uint8_t*)malloc(12);
    if (NVSDriverReadBlob(NVS_NAMESPACE_SEC, NVS_KEY_SEC_NONCE, &nonce_temp) == ESP_OK) {
        memcpy(nonce, nonce_temp, 12);
    }
    free(nonce_temp);
}

bool encryptData(const uint8_t* input, uint8_t* output, size_t dataSize){
    if (dataSize == 0 || dataSize > 32) {
        return false;
    }
    crypto_info_t crypto_info = {};
    load_crypto_info(crypto_info.key, crypto_info.nonce);
    // Serial.println("Key: ");
    // for (size_t i = 0; i < 12; i++) {
    //     Serial.print(crypto_info.key[i], HEX);
    //     if (i < 12 - 1) Serial.print(" ");
    // }
    // Serial.println();
    // Serial.println("Nonce: ");
    // for (size_t i = 0; i < 12; i++) {
    //     Serial.print(crypto_info.nonce[i], HEX);
    //     if (i < 12 - 1) Serial.print(" ");
    // }
      
    ChaCha chaCha;
    chaCha.setKey(crypto_info.key, 32);
    chaCha.setIV(crypto_info.nonce, 12);
    
    chaCha.encrypt(output, input, dataSize);
    return true;
}

bool isCrytoInfoAvailable(void){
    crypto_info_t crypto_info = {};
    load_crypto_info(crypto_info.key, crypto_info.nonce);
    for (size_t i = 0; i < 32; i++) {
      if (crypto_info.key[i] != 0) {
          return true;
      }
    }
    for (size_t i = 0; i < 12; i++) {
      if (crypto_info.nonce[i] != 0) {
          return true;
      }
  }
  return false;  
}
