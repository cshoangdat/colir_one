#ifndef __UTIL_H__
#define __UTIL_H__

#include "config.h"
#include "stdio.h"

#ifdef __cplusplus
extern "C" {
#endif

int hexStringToBytes(const char* hex_string, uint8_t* output, uint16_t max_output_len);

#ifdef __cplusplus
}
#endif

#endif
