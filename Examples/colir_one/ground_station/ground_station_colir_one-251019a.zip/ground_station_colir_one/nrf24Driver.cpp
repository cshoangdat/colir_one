#include "nrf24Driver.h"
#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>

static RF24 radio(RF24_CE_PIN, RF24_CSN_PIN); // CE, CSN

static colirone_payload_cmd_t colirone_payload_cmd_queue[NRF24_QUEUE_SIZE];
static int queueHead = 0;
static int queueTail = 0;

void nrf24Init(const uint8_t* RxAddress, const uint8_t* TxAddress){
  radio.begin();
  radio.setAutoAck(false);
  radio.setDataRate(RF24_250KBPS);
  radio.setPALevel(RF24_PA_MAX);
  radio.setRetries(5,5);
  radio.disableCRC();
  radio.openReadingPipe(0, RxAddress);
  radio.openWritingPipe(TxAddress);
  radio.startListening();
}

bool nrf24Available(void){
  return radio.available();
}

void nrf24Read(uint8_t* buffer, size_t len){
  radio.read(buffer, len);
}

static void transmit_cmd(colirone_payload_cmd_t colirone_payload_cmd){
  radio.stopListening();
  int ret = radio.write((uint8_t*)&colirone_payload_cmd, sizeof(colirone_payload_cmd));
  if(ret == 0){
    Serial.println("transmit_launch_cmd success");
  }
  delay(50);
  radio.startListening();  
}

void nrf24EnqueueCMD(colirone_payload_cmd_t command) {
    if ((queueTail + 1) % NRF24_QUEUE_SIZE != queueHead) {
        colirone_payload_cmd_queue[queueTail] = command;
        queueTail = (queueTail + 1) % NRF24_QUEUE_SIZE;
    }
}

void nrf24ProcessCMD(void) {
    if (queueHead != queueTail) {
        colirone_payload_cmd_t colirone_payload_cmd = colirone_payload_cmd_queue[queueHead]; 
        queueHead = (queueHead + 1) % NRF24_QUEUE_SIZE;
        transmit_cmd(colirone_payload_cmd);
    }
}

// Thêm hàm transmit cho raw byte array
static void transmit_raw_cmd(uint8_t* cmd, size_t size){
  radio.stopListening();
  int ret = radio.write(cmd, size);
  if(ret == 0){
    Serial.println("transmit_raw_cmd success");
  }
  delay(50);
  radio.startListening();  
}

// Queue cho raw commands
#define RAW_CMD_QUEUE_SIZE 10
static uint8_t raw_cmd_queue[RAW_CMD_QUEUE_SIZE][32];
static uint8_t raw_cmd_sizes[RAW_CMD_QUEUE_SIZE];
static uint8_t rawQueueHead = 0;
static uint8_t rawQueueTail = 0;

void nrf24EnqueueRawCMD(uint8_t* cmd, uint8_t size) {
    if (size > 32) {
        Serial.println("Error: Command size exceeds 32 bytes");
        return;
    }
    
    if ((rawQueueTail + 1) % RAW_CMD_QUEUE_SIZE != rawQueueHead) {
        memcpy(raw_cmd_queue[rawQueueTail], cmd, size);
        raw_cmd_sizes[rawQueueTail] = size;
        rawQueueTail = (rawQueueTail + 1) % RAW_CMD_QUEUE_SIZE;
        Serial.print("Raw command enqueued, size: ");
        Serial.println(size);
    } else {
        Serial.println("Raw command queue is full!");
    }
}

void nrf24ProcessRawCMD(void) {
    if (rawQueueHead != rawQueueTail) {
        uint8_t* cmd = raw_cmd_queue[rawQueueHead];
        uint8_t size = raw_cmd_sizes[rawQueueHead];
        rawQueueHead = (rawQueueHead + 1) % RAW_CMD_QUEUE_SIZE;
        
        Serial.print("Processing raw command, size: ");
        Serial.println(size);
        transmit_raw_cmd(cmd, size);
    }
}

// void nrf24EnqueueCMD(uint8_t* cmd, uint8_t size = 32) {
//     nrf24EnqueueRawCMD(cmd, size);
// }

// void nrf24ProcessAllCMD(void) {
//     // Process structured commands first
//     nrf24ProcessCMD();
    
//     // Then process raw commands
//     nrf24ProcessRawCMD();
// }