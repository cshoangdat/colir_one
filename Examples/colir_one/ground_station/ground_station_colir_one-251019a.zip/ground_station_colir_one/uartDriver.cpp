#include "uartDriver.h"
#include "common.h"
#include "NVSDriver.h"
#include "util.h"
#include <ArduinoJson.h>

#define MAX_INPUT 111

// here to process incoming serial data after a terminator received
static void process_data (const char * data)
{
  crypto_info_t info = {};
  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, data);
  if (error) {
    Serial.print(F("deserializeJson() failed: "));
    Serial.println(error.f_str());
    return;
  }
  const char* keyStr = doc["key"];
  const char* nonceStr = doc["nonce"];
  Serial.print("Key: ");
  Serial.println(keyStr);
  Serial.print("Nonce: ");
  Serial.println(nonceStr);
  int keyLen = hexStringToBytes(keyStr,info.key, sizeof(info.key));
  int nonceLen = hexStringToBytes(nonceStr, info.nonce, sizeof(info.nonce));
  if(keyLen != 0 && nonceLen != 0){
    NVSDriverWriteBlob(NVS_NAMESPACE_SEC, NVS_KEY_SEC_NONCE, info.nonce, 12);
    NVSDriverWriteBlob(NVS_NAMESPACE_SEC, NVS_KEY_SEC_KEY, info.key, 32);    
  }
}
  
static void processIncomingByte (const byte inByte)
  {
  static char input_line [MAX_INPUT];
  static unsigned int input_pos = 0;

  switch (inByte)
    {

    case '\n':   // end of text
      input_line [input_pos] = 0;  // terminating null byte
      
      // terminator reached! process input_line here ...
      process_data (input_line);
      
      // reset buffer for next time
      input_pos = 0;  
      break;

    case '\r':   // discard carriage return
      break;

    default:
      // keep adding if not full ... allow for terminating null byte
      if (input_pos < (MAX_INPUT - 1))
        input_line [input_pos++] = inByte;
      break;

    }  // end of switch
   
  } // end of processIncomingByte  

void serialReadHandler(void){
  while (Serial.available () > 0)
    processIncomingByte (Serial.read());
}