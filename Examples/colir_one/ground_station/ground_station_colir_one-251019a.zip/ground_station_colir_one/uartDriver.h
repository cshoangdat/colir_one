#ifndef __UARTDRIVER_H__
#define __UARTDRIVER_H__

#include "config.h"
#include "stdio.h"

#ifdef __cplusplus
extern "C" {
#endif

void serialReadHandler(void);

#ifdef __cplusplus
}
#endif

#endif
